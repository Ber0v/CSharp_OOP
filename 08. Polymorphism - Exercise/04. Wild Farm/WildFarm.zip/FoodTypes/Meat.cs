﻿using WildFarm.BaseClasses;

namespace WildFarm.FoodTypes
{
    public class Meat : Food
    {
        public Meat(int quantity)
            : base(quantity) { }
    }
}
