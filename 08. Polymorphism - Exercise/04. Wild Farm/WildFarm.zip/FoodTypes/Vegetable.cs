﻿using WildFarm.BaseClasses;

namespace WildFarm.FoodTypes
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity)
            : base(quantity) { }
    }
}
