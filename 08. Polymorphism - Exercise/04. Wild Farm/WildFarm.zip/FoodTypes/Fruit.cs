﻿using WildFarm.BaseClasses;

namespace WildFarm.FoodTypes
{
    public class Fruit : Food
    {
        public Fruit(int quantity)
            : base(quantity) { }
    }
}
