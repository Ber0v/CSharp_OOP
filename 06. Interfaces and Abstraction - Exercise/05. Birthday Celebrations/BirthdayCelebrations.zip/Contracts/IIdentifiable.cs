﻿namespace BirthdayCelebrations.Contracts
{
    public interface IIdentifiable
    {
        string Id { get; set; }
    }
}
