﻿namespace InfluencerManagerApp.Models
{
    public class ServiceCampaign : Campaign
    {
        public ServiceCampaign(string brand) : base(brand, 30000)
        {
        }
    }
}
