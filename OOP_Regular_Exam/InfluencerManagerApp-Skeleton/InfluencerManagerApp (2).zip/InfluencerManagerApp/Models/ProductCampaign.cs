﻿namespace InfluencerManagerApp.Models
{
    public class ProductCampaign : Campaign
    {
        public ProductCampaign(string brand) : base(brand, 60000)
        {
        }
    }
}
